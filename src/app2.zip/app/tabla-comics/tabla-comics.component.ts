import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { TablaComicsDataSource, TablaComicsItem } from './tabla-comics-datasource';
import { ComicComponent } from '../comic/comic.component';

@Component({
  selector: 'app-tabla-comics',
  templateUrl: './tabla-comics.component.html',
  styleUrls: ['./tabla-comics.component.css']
})
export class TablaComicsComponent implements AfterViewInit, OnInit {
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  @ViewChild(MatTable, {static: false}) table: MatTable<TablaComicsItem>;
  dataSource: TablaComicsDataSource;
  comic: ComicComponent;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['id', 'nombre', 'autor','genero','imagen', 'favorito'];  

  ngOnInit() {
    this.dataSource = new TablaComicsDataSource();
    this.comic = new ComicComponent();
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }
}
