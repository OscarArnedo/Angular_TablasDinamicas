import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';

@Component({
  selector: 'app-comic',
  templateUrl: './comic.component.html',
  styleUrls: ['./comic.component.css']
})

export class ComicComponent implements OnInit {
  public comics = [];

  myControl = new FormControl();
  options: string[] = ['Asterix','Tintin','Xmen','Hulk','Spiderman','Aquaman','Superman'];
  filteredOptions: Observable<string[]>;

  constructor() {
    this.comics.push(new Comic("Asterix y los Normandos","René Goscinny","Aventuras","asterix.jpg"));
    this.comics.push(new Comic("Tintin Aterrizaje en la luna","Hergé","Aventuras","tintin.jpg"));
    this.comics.push(new Comic("Xmen","Marvel","Superheroes","xmen.jpg"));
    this.comics.push(new Comic("Aquaman","Marvel","Superheroes","acuaman.jpg"));
    this.comics.push(new Comic("El increíble hulk","Stan Lee","Superheroes","hulk.jpg"));
    this.comics.push(new Comic("Spiderman","Marvel","Superheroes","spiderman.jpg"));
    this.comics.push(new Comic("Superman","DC","Superheroes","superman.jpg"));
   }

  ngOnInit() {
    if(localStorage.getItem('Favoritos') == null){
      localStorage.setItem("Favoritos","");
    }
    
    this.filteredOptions = this.myControl.valueChanges
    .pipe(
      startWith(''),
      map(value => this._filter(value))
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }
  
  anadirFavorito(t:string){
    try {
      let favs = localStorage.getItem('Favoritos').split(',');
      if (favs != null) {
        favs.push(t);
        let join = favs.join(',');
        localStorage.setItem('Favoritos', join);
      } else {
        localStorage.setItem('Favoritos', [t].toString());
      }
    } catch (err) {
      console.log(err);
    }
  }

  getComic(t:number){
    return this.comics[t];
  }

}
export class Comic {
  private titulo:String;
  private autor:String;
  private genero:String;
  private imagen:String;

  constructor(titulo:String, autor:String, genero:String, imagen:String) {
    this.titulo = titulo;
    this.autor = autor;
    this.genero = genero;
    this.imagen = imagen;
  }

  getNombre(){
    return this.titulo;
  }

  getAutor(){
    return this.autor;
  }

  getGenero(){
    return this.genero;
  }

  getImagen(){
    return this.imagen;
  }
  
}

