import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InicioComponent } from './inicio/inicio.component';
import { FavoritosComponent } from './favoritos/favoritos.component';
import { ComicComponent } from './comic/comic.component';
import { MangaComponent } from './manga/manga.component';
import { PaginaComponent } from './pagina/pagina.component';
import { DialogOverviewExample, DialogOverviewExampleDialog } from './popup/dialog-overview-example';

const routes: Routes = [
  { path: 'inicio', component: InicioComponent },
  { path: 'favoritos', component: FavoritosComponent },
  { path: 'comic', component: ComicComponent },
  { path: 'manga', component: MangaComponent },
  { path: 'pagina', component: PaginaComponent},
  { path: 'popup', component: DialogOverviewExample},


  { path: 'inicio', redirectTo: '/inicio', pathMatch: 'full' },

  { path: 'favoritos', redirectTo: '/favoritos' },

  { path: 'comic', redirectTo: '/comic'},

  { path: 'manga', redirectTo: '/manga'},

  { path: 'pagina', redirectTo: '/pagina'},

  { path: 'popup', redirectTo: '/popup'},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
