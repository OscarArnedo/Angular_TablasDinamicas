import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';

@Component({
  selector: 'app-manga',
  templateUrl: './manga.component.html',
  styleUrls: ['./manga.component.css']
})

export class MangaComponent implements OnInit {
  public mangas = [];
  /*
  myControl = new FormControl();
  options: string[] = ['Asterix','Tintin','Xmen','Hulk','Spiderman','Aquaman','Superman'];
  filteredOptions: Observable<string[]>;*/

  constructor() {
    this.mangas.push(new Comic("Dragon Ball","Akira Toriyama","Lucha","dball.jpg"));
    this.mangas.push(new Comic("Assasination Classroom","Yusei Matsui","Comedia","ac.jpg"));
    this.mangas.push(new Comic("Naruto","Masashi Kishimoto","Lucha","naruto.jpg"));
    this.mangas.push(new Comic("One Piece","Eiichiro Oda","Lucha","opiece.jpg"));
    this.mangas.push(new Comic("Berserk","Kentaro Miura","Horror","berserk.jpg"));
    this.mangas.push(new Comic("Death Note","Marvel","Takeshi Obata","dnote.jpg"));
    this.mangas.push(new Comic("Attack on Titans","Hajime Isayama","Accion","aot.jpg"));
   }

  ngOnInit() {
    if(localStorage.getItem('Favoritos') == null){
      localStorage.setItem("Favoritos","");
    }
    
    /*this.filteredOptions = this.myControl.valueChanges
    .pipe(
      startWith(''),
      map(value => this._filter(value))
    );*/
  }

  /*private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }*/
  
  anadirFavorito(t:string){
    try {
      let favs = localStorage.getItem('Favoritos').split(',');
      if (favs != null) {
        favs.push(t);
        let join = favs.join(',');
        localStorage.setItem('Favoritos', join);
      } else {
        localStorage.setItem('Favoritos', [t].toString());
      }
    } catch (err) {
      console.log(err);
    }
  }

  getManga(t:number){
    return this.mangas[t];
  }

}
export class Comic {
  private titulo:String;
  private autor:String;
  private genero:String;
  private imagen:String;

  constructor(titulo:String, autor:String, genero:String, imagen:String) {
    this.titulo = titulo;
    this.autor = autor;
    this.genero = genero;
    this.imagen = imagen;
  }

  getNombre(){
    return this.titulo;
  }

  getAutor(){
    return this.autor;
  }

  getGenero(){
    return this.genero;
  }

  getImagen(){
    return this.imagen;
  }
  
}

